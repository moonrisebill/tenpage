module Fastlane
  module IonicIntegration
    VERSION = "0.1.3"
  end
end
